---
name: dev-docs
description: Anthropic's official Claude development documentation. Index to SDK, tools, skills, MCP, and capabilities. Use when building agents, implementing tools, writing skills, or working with the Messages API.
---

# Claude Dev Docs Index

Anthropic's official Claude development documentation. Use `view` to lazy-load any file.

## Quick Paths

### Core Reference
- `features overview.md` — Model capabilities, pricing tiers, rate limits
- `context windows.md` — Token limits, context management strategies  
- `using the messages api.md` — Messages API request/response patterns
- `prompting best practices.md` — Prompt engineering techniques

### Agent SDK (`sdk agent/`)
| File | Contents |
|------|----------|
| `overview.md` | SDK architecture, Python/TS entry points |
| `quickstart.md` | Bug-fixing agent in 5 minutes |
| `python sdk.md` | Full Python API reference |
| `typescript_guide.md` | Full TypeScript API reference |
| `migration.md` | Claude Code SDK → Agent SDK |

**Guides** (`sdk agent/guides/`):
- `custom tools.md` — Build tools with input schemas
- `control execution with hooks.md` — Pre/post hooks, abort, modify
- `modifying system prompts.md` — Inject context, personas
- `session management.md` — Conversation state persistence
- `structured outputs.md` — Guaranteed JSON schema conformance
- `sub agents in the sdk.md` — Orchestrate multiple agents
- `handling permissions.md` — Tool approval flows
- `securely deploying agents.md` — Auth, sandboxing, prod hardening
- `mcp in the sdk.md` — Connect MCP servers to agents
- `plugins in the sdk.md` — Extend agent capabilities
- `slash commands in the sdk.md` — Custom /commands
- `streaming input.md` — Real-time input handling
- `tracking cost and usage.md` — Token/cost monitoring
- `todo lists.md` — Task management patterns
- `agent skills in the sdk.md` — Load skills programmatically
- `hosting sdk.md` — Deployment options

### Tools (`tools/`)
- `overview.md` — Tool use fundamentals, JSON schema definitions
- `how to implement.md` — End-to-end tool implementation guide
- `Programmatic tool calling.md` — Forced tool use, tool_choice
- `Computer use tool.md` — Screen control, mouse/keyboard automation
- `Web fetch tool.md` — HTTP requests from Claude
- `tool search tool.md` — Dynamic tool discovery

### Skills (`skills/`)
- `Agent Skills.md` — What skills are, SKILL.md anatomy
- `quickstart.md` — Build your first skill
- `Skill authoring best practices.md` — Concise writing, testing
- `Using Agent Skills with the API.md` — Programmatic skill loading

### Capabilities (`capabilities/`)
- `Vision.md` — Image input, multi-modal prompts
- `Streaming Messages.md` — SSE streaming, delta handling
- `Batch processing.md` — Async bulk requests, 50% cost savings
- `Context editing.md` — Modify conversation history
- `Effort.md` — Extended thinking, reasoning depth
- `Embeddings.md` — Voyage AI integration

### MCP (`mcp/`)
- `MCP connector.md` — Model Context Protocol setup
- `Remote MCP servers.md` — External MCP connections
